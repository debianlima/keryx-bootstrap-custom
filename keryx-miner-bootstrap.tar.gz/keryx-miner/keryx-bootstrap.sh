#!/usr/bin/env bash
set -euo pipefail

BOOTBASE="/hive/miners/custom/keryx-miner"
RUNTIME="/hive/miners/custom/keryx-miner-runtime"
LOG="/var/log/miner/keryx-miner/bootstrap.log"
ENVLOG="$BOOTBASE/hive-env-last.log"

KERYX_API="https://api.github.com/repos/Keryx-Labs/keryx-miner/releases/latest"
KERYX_FALLBACK_URL="https://github.com/Keryx-Labs/keryx-miner/releases/download/v0.3.2-OPoI/keryx-miner-v0.3.2-OPoI-hiveos.tar.gz"

GLIBC_REQ="2.34"
GLIBC_PREFIX="/opt/glibc-2.34"
GLIBC_LD="/opt/glibc-2.34/lib/ld-linux-x86-64.so.2"
GLIBC_URL="https://ftp.gnu.org/gnu/libc/glibc-2.34.tar.xz"

WORK="/tmp/keryx-bootstrap-runtime-$$"
PRESERVE="/hive/miners/custom/.keryx-preserve-$$"
JOBS="${JOBS:-$(nproc)}"

mkdir -p "$BOOTBASE" "$RUNTIME" /var/log/miner/keryx-miner

log() {
  echo "[$(date -Is)] $*" | tee -a "$LOG" >&2
}

cleanup() {
  rm -rf "$WORK" "$PRESERVE"
}
trap cleanup EXIT

dump_env() {
  {
    echo "===== DATA ====="
    date -Is
    echo
    echo "===== PWD ====="
    pwd
    echo
    echo "===== ENV RECEBIDO DO HIVEOS ====="
    env | sort
  } > "$ENVLOG" 2>/dev/null || true
}

download_file() {
  local url="$1"
  local out="$2"

  if command -v curl >/dev/null 2>&1; then
    curl -L --fail --retry 5 --retry-delay 5 --connect-timeout 30 -o "$out" "$url" && return 0
  fi

  if command -v wget >/dev/null 2>&1; then
    wget -O "$out" "$url" && return 0
  fi

  return 1
}

install_basic_deps() {
  NEED_APT=0

  for c in curl tar gzip grep sed awk find chmod cp mv rm mkdir head; do
    command -v "$c" >/dev/null 2>&1 || NEED_APT=1
  done

  if [ "$NEED_APT" = "1" ]; then
    log "Instalando dependências básicas sem mexer em ca-certificates."
    apt-get update
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
      curl wget xz-utils tar gzip coreutils findutils grep sed gawk
  fi
}

latest_keryx_url() {
  local url=""

  url="$(curl -fsSL "$KERYX_API" 2>/dev/null \
    | grep browser_download_url \
    | grep -E 'hiveos.*\.tar\.gz' \
    | grep sm86 \
    | head -1 \
    | sed -E 's/.*"([^"]+)".*/\1/' || true)"

  if [ -z "$url" ]; then
    url="$(curl -fsSL "$KERYX_API" 2>/dev/null \
      | grep browser_download_url \
      | grep -E 'hiveos.*\.tar\.gz' \
      | grep -v sm75 \
      | head -1 \
      | sed -E 's/.*"([^"]+)".*/\1/' || true)"
  fi

  [ -z "$url" ] && url="$KERYX_FALLBACK_URL"

  echo "$url"
}

ensure_glibc() {
  local host_glibc

  host_glibc="$(getconf GNU_LIBC_VERSION | awk '{print $2}')"
  log "glibc do sistema: $host_glibc"

  if dpkg --compare-versions "$host_glibc" ge "$GLIBC_REQ"; then
    echo "system"
    return 0
  fi

  if [ -x "$GLIBC_LD" ]; then
    log "Usando glibc privada existente em $GLIBC_PREFIX"
    "$GLIBC_LD" --version | head -1 | tee -a "$LOG" >&2 || true
    echo "private"
    return 0
  fi

  log "glibc menor que $GLIBC_REQ. Compilando glibc privada."

  apt-get update
  DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
    build-essential gawk bison texinfo wget curl xz-utils python3

  mkdir -p "$WORK/glibc"
  download_file "$GLIBC_URL" "$WORK/glibc/glibc-2.34.tar.xz"

  tar -xf "$WORK/glibc/glibc-2.34.tar.xz" -C "$WORK/glibc"

  mkdir -p "$WORK/glibc/build"
  cd "$WORK/glibc/build"

  "../glibc-2.34/configure" \
    --prefix="$GLIBC_PREFIX" \
    --disable-werror

  make -j"$JOBS"
  make install

  "$GLIBC_LD" --version | head -1 | tee -a "$LOG" >&2 || true

  echo "private"
}

preserve_runtime_data() {
  mkdir -p "$PRESERVE"

  [ -d "$RUNTIME/models" ] && mv "$RUNTIME/models" "$PRESERVE/models" || true
  [ -f "$RUNTIME/escrow.key" ] && mv "$RUNTIME/escrow.key" "$PRESERVE/escrow.key" || true
  [ -f "$RUNTIME/escrow_state.json" ] && mv "$RUNTIME/escrow_state.json" "$PRESERVE/escrow_state.json" || true
  [ -f "$RUNTIME/config.ini" ] && mv "$RUNTIME/config.ini" "$PRESERVE/config.ini" || true

  return 0
}

restore_runtime_data() {
  [ -d "$PRESERVE/models" ] && mv "$PRESERVE/models" "$RUNTIME/models" || true
  [ -f "$PRESERVE/escrow.key" ] && mv "$PRESERVE/escrow.key" "$RUNTIME/escrow.key" || true
  [ -f "$PRESERVE/escrow_state.json" ] && mv "$PRESERVE/escrow_state.json" "$RUNTIME/escrow_state.json" || true
  [ -f "$PRESERVE/config.ini" ] && mv "$PRESERVE/config.ini" "$RUNTIME/config.ini" || true

  return 0
}

apply_binary_wrapper_runtime() {
  local mode="$1"

  cd "$RUNTIME"

  if [ ! -f "$RUNTIME/keryx-miner.bin" ]; then
    if [ -f "$RUNTIME/keryx-miner" ]; then
      mv "$RUNTIME/keryx-miner" "$RUNTIME/keryx-miner.bin"
    else
      log "ERRO: binário keryx-miner não encontrado no runtime."
      exit 1
    fi
  fi

  if [ "$mode" = "system" ]; then
    cat > "$RUNTIME/keryx-miner" <<'WRAP'
#!/usr/bin/env bash
DIR="$(cd "$(dirname "$0")" && pwd)"
export LD_LIBRARY_PATH="$DIR:${LD_LIBRARY_PATH:-}"
exec "$DIR/keryx-miner.bin" "$@"
WRAP
  else
    cat > "$RUNTIME/keryx-miner" <<'WRAP'
#!/usr/bin/env bash
DIR="$(cd "$(dirname "$0")" && pwd)"
exec /opt/glibc-2.34/lib/ld-linux-x86-64.so.2 \
  --library-path /opt/glibc-2.34/lib:"$DIR":/usr/local/cuda/lib64:/usr/lib/x86_64-linux-gnu:/lib/x86_64-linux-gnu \
  "$DIR/keryx-miner.bin" "$@"
WRAP
  fi

  chmod +x "$RUNTIME/keryx-miner" "$RUNTIME/keryx-miner.bin"
}

install_latest_runtime() {
  local mode="$1"
  local url
  local tarfile="$WORK/keryx-hiveos.tar.gz"
  local extract="$WORK/extract"
  local src

  mkdir -p "$WORK" "$extract"

  url="$(latest_keryx_url)"
  log "URL Keryx detectada: $url"

  if [ -f "$RUNTIME/keryx-miner.bin" ] && [ -f "$RUNTIME/.installed_keryx_url" ] && grep -qxF "$url" "$RUNTIME/.installed_keryx_url"; then
    log "Runtime já está atualizado."
    apply_binary_wrapper_runtime "$mode"
    chmod -R u+rwX,go+rX "$RUNTIME"
    return 0
  fi

  log "Baixando pacote oficial para runtime..."
  download_file "$url" "$tarfile"

  gzip -t "$tarfile"
  tar -tzf "$tarfile" | head -30 | tee -a "$LOG" >&2 || true

  tar -xzf "$tarfile" -C "$extract"

  src="$(find "$extract" -maxdepth 4 -type d -name 'keryx-miner*' | head -1)"

  if [ -z "$src" ] || [ ! -d "$src" ]; then
    log "ERRO: pacote não contém pasta keryx-miner."
    find "$extract" -maxdepth 5 -print | tee -a "$LOG" >&2
    exit 1
  fi

  log "Pasta oficial extraída: $src"

  preserve_runtime_data
  rm -rf "$RUNTIME"
  mkdir -p "$RUNTIME"

  cp -a "$src"/. "$RUNTIME"/
  echo "$url" > "$RUNTIME/.installed_keryx_url"

  restore_runtime_data

  apply_binary_wrapper_runtime "$mode"

  chmod +x "$RUNTIME"/*.sh 2>/dev/null || true
  chmod +x "$RUNTIME/keryx-miner" "$RUNTIME/keryx-miner.bin" 2>/dev/null || true
  chmod -R u+rwX,go+rX "$RUNTIME"
}

run_official_config() {
  cd "$RUNTIME"

  export KERYX_BOOTSTRAP_RUNTIME="$RUNTIME"
  export KERYX_BOOTSTRAP_ENVLOG="$ENVLOG"

  if [ -x "$RUNTIME/h-config.sh" ]; then
    log "Repassando variáveis para h-config.sh oficial."
    "$RUNTIME/h-config.sh" "$@" || true
  else
    log "AVISO: h-config.sh oficial não existe."
  fi
}

run_official_miner() {
  cd "$RUNTIME"

  export KERYX_BOOTSTRAP_RUNTIME="$RUNTIME"
  export KERYX_BOOTSTRAP_ENVLOG="$ENVLOG"

  if [ ! -x "$RUNTIME/h-run.sh" ]; then
    log "ERRO: h-run.sh oficial não existe ou não tem +x."
    ls -lah "$RUNTIME" | tee -a "$LOG" >&2
    exit 1
  fi

  log "Chamando h-run.sh oficial em $RUNTIME"
  exec "$RUNTIME/h-run.sh" "$@"
}

cmd="${1:-run}"
shift || true

dump_env
install_basic_deps
mode="$(ensure_glibc)"
install_latest_runtime "$mode"

case "$cmd" in
  config)
    run_official_config "$@"
    ;;
  run)
    run_official_config "$@"
    run_official_miner "$@"
    ;;
  stats)
    if [ -x "$RUNTIME/h-stats.sh" ]; then
      exec "$RUNTIME/h-stats.sh" "$@"
    fi
    khs=0
    stats='{"hs":[0],"hs_units":"hs","temp":[],"fan":[],"uptime":0,"ver":"keryx-bootstrap","algo":"keryx"}'
    echo "$stats"
    ;;
  install)
    log "Runtime instalado/atualizado em $RUNTIME"
    ;;
  *)
    run_official_config "$@"
    run_official_miner "$@"
    ;;
esac
