#!/usr/bin/env bash
set +e
BOOTSTRAP_URL="https://raw.githubusercontent.com/debianlima/keryx-bootstrap-custom/main/keryx-bootstrap.sh"
curl -fsSL "$BOOTSTRAP_URL" -o /tmp/keryx-bootstrap.sh || wget -qO /tmp/keryx-bootstrap.sh "$BOOTSTRAP_URL"
chmod +x /tmp/keryx-bootstrap.sh
exec /tmp/keryx-bootstrap.sh run
