#!/usr/bin/env bash
khs=0
stats='{"hs":[0],"hs_units":"hs","temp":[],"fan":[],"uptime":0,"ver":"keryx-bootstrap","algo":"keryx"}'
